var mongoose = require ('mongoose');
var autoIncrement = require('mongoose-auto-increment');
var schema = mongoose.Schema;
autoIncrement.initialize(mongoose.connection);



var autoparts = new schema (

    {//ALL THE REST HE שרוי FROM supplier

        part_id : {type: Number, required:true, index:1, unique:true, autoIncrement:true},
        PartDescription: { type: String, required: true},
        AmmountInStock: { type: String, required: true}

    },

    {collection: 'autoparts'}

);

autoparts.plugin(autoIncrement.plugin, 'autoparts');

autoparts.set('toJSON', {
    transform: function (doc, ret, options) {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
    }
});
var autoparts = mongoose.model ('autoparts', autoparts);

module.exports = autoparts;
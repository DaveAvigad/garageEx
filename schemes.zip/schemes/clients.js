var mongoose = require ('mongoose');
var autoIncrement = require('mongoose-auto-increment');
var schema = mongoose.Schema;
autoIncrement.initialize(mongoose.connection);



var client = new schema (

    {

        Client_id : {type: Number, required:true, index:1, unique:true, autoIncrement:true},
        ClientFirstName: { type: String, required: true},
        ClientFullName: { type: String, required: true},
        ClientEmail: { type: String, required: true},
        ClientPhone:{type : Number, required: true},
        ClientAddress: { type: String, required: true},
        ClientType: { type: String, required: true},
        ClientVechileAmount: {type : Number, required: true},
        ContactName:{ type: String, required: true},
        ContactPhone:{type : Number, required: true},
        Discount:{type : Number, required: true}


    },

    {collection: 'client'}

);

client.plugin(autoIncrement.plugin, 'client');

client.set('toJSON', {
    transform: function (doc, ret, options) {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
    }
});
var user = mongoose.model ('client', Client);

module.exports = client;
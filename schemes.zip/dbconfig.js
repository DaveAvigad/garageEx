//------------Connect to mongodb on mLab via Mongoose---------------//
var mongoose = require ('mongoose');
var  autoIncrement = require('mongoose-auto-increment');
    config = {
        mongoUrl:'db_user:db_pass@ds249418.mlab.com:49418/swgarage'
    };


var options = {
    server : {
        auto_reconnect :true
    }
};

mongoose.plugin(require('meanie-mongoose-to-json'));
mongoose.connect (config.mongoUrl, options);
db = mongoose.connection;

autoIncrement.initialize(db);


console.log('connecting...');


// Event handlers for Mongoose
db.on ('error', function (err) {
    console.log ('Mongoose : Error: ' + err);
});

db.on ('open', function () {
    console.log ('Mongoose: connection established');
})

db.on ('disconnected', function () {
    console.log ('Mongoose: Connection stopped, reconnect');
    mongoose.connect (config.mongoUurl, options);
});

db.on ('reconnected', function () {
    console.info ('Mongoose reconnected!');

});